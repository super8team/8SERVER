<?php

use Illuminate\Database\Seeder;

class FieldLearningPlanDocumentsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('field_learning_plan_documents')->insert([

            ['article' => '전세버스', 'name' => '', 'explain' => '', 'work' => '', 'document_url' => ''],


        ]);
    }
}
